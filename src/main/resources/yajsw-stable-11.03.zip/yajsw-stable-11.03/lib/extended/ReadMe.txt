The following libraries provide extended functionalites to YAJSW:

Timers require:
	* quartz
	
Posix Installation of daemons requires:
	* velocity
	
System tray requires:
	* abeille
	* jgoodies
	* yajsw

ServiceManager requires:
	* abeille
	* jgoodies
	* glazed lists
	* hessian

Network loading in general
	* commons
	
Network loading per webdav
	* vfs-webdav

