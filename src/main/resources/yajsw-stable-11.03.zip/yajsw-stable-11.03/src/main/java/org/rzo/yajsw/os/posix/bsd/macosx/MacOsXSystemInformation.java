package org.rzo.yajsw.os.posix.bsd.macosx;

import java.util.logging.Logger;

import org.rzo.yajsw.os.SystemInformation;

public class MacOsXSystemInformation implements SystemInformation
{

	public long freeRAM()
	{
		// TODO Auto-generated method stub
		return 0;
	}

	public long totalRAM()
	{
		// TODO Auto-generated method stub
		return 0;
	}

	public void setLogger(Logger logger)
	{
		// TODO Auto-generated method stub

	}

}
