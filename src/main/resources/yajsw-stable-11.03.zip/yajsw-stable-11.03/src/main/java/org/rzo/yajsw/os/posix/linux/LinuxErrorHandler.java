package org.rzo.yajsw.os.posix.linux;

import org.rzo.yajsw.os.posix.PosixErrorHandler;

public class LinuxErrorHandler extends PosixErrorHandler
{

}
