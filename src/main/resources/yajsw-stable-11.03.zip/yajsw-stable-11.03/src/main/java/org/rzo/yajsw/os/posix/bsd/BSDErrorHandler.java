package org.rzo.yajsw.os.posix.bsd;

import org.rzo.yajsw.os.ErrorHandler;
import org.rzo.yajsw.os.OsException;

public class BSDErrorHandler implements ErrorHandler
{

	public void throwException(int id) throws OsException
	{
		// TODO Auto-generated method stub

	}

	public String toString(int id)
	{
		// TODO Auto-generated method stub
		return null;
	}

}
