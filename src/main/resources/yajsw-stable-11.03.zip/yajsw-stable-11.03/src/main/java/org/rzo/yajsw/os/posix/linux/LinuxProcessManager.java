package org.rzo.yajsw.os.posix.linux;

import org.rzo.yajsw.os.posix.PosixProcessManager;

public class LinuxProcessManager extends PosixProcessManager
{
}
