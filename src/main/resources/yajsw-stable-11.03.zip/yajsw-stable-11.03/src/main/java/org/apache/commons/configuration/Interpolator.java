package org.apache.commons.configuration;

public interface Interpolator
{
	public Object interpolate(Object name);

}
